# pygame stuff will go here

import pygame
import configparser
import time
import random
import threading
import sys

# read config
defaults_config = configparser.ConfigParser()
defaults_config.read("./config/defaults.config")
defaults_config = defaults_config["VEHICLE"]


# Screensize; this also can be fetched from defaults file
screenWidth = 1358
screenHeight = 730

# assuming
roadLength = 200

marginX = 10
# co-ordinates where vehicle starts
x = {
    "EAST": [0, 0, 0],
    "NORTH": [550, 580],
    "WEST": [
        0,
        0,
        0,
    ],
    "SOUTH": [602, 627, 657],
}

print(x)

y = {
    "EAST": [348, 370, 398],
    "NORTH": [0, 0, 0],
    "WEST": [498, 466, 436],
    "SOUTH": [800, 800, 800],
}

# Default values of signal timers, this will be set laterrrrr
defaultGreen = {0: 10, 1: 10, 2: 10, 3: 10}
defaultRed = 150
defaultYellow = 5

# signal times, 4 signals are there
signals = []
noOfSignals = 4
currentGreen = 0  # Indicates which signal is green currently
currentYellow = 0  # Indicates whether yellow signal is on or off
nextGreen = (
    currentGreen + 1
) % noOfSignals  # Indicates which signal will turn green next

# Coordinates of signal image, timer, and vehicle count

# these are temp vars
margin1X = 10
margin1Y = 65
sig1X = ((screenWidth - (screenWidth * 0.2)) / 2 - roadLength / 2) - margin1X
sig1Y = (screenHeight / 2 - roadLength / 2) - margin1Y
margin2X = -23
margin2y = -23
sig2X = ((screenWidth - (screenWidth * 0.2)) / 2 + roadLength / 2) + margin2X
sig2Y = (screenHeight / 2 + roadLength / 2) + margin2y

signalCoods = [(sig1X, sig1Y), (sig2X, sig1Y), (sig2X, sig2Y), (sig1X, sig2Y)]
signalTimerCoods = [
    (sig1X, sig1Y - 20),
    (sig2X, sig1Y - 20),
    (sig2X, sig2Y + 90),
    (sig1X, sig2Y + 90),
]

# Coordinates of stop lines
margin1X = 10
margin1Y = 30
stop1X = ((screenWidth - (screenWidth * 0.2)) / 2 - roadLength / 2) - margin1X
stop1Y = (screenHeight / 2 - roadLength / 2) + margin1Y
margin2X = 0
margin2y = 0
stop2X = ((screenWidth - (screenWidth * 0.2)) / 2 + roadLength / 2) + margin2X
stop2Y = (screenHeight / 2 + roadLength / 2) - margin2y

stopLines = {"EAST": stop1X, "NORTH": stop1Y, "WEST": stop2X, "SOUTH": stop2Y}
defaultStop = {
    "EAST": stop1X - 10,
    "NORTH": stop1Y - 10,
    "WEST": stop2X + 10,
    "SOUTH": stop2Y + 10,
}
print(stopLines)
print(defaultStop)

# direction numbers
directionNumbers = {0: "EAST", 1: "NORTH", 2: "WEST", 3: "SOUTH"}

# all vehicles in the scene, now
vehicles = {
    "EAST": {0: [], 1: [], 2: [], "crossed": 0},
    "NORTH": {0: [], 1: [], 2: [], "crossed": 0},
    "WEST": {0: [], 1: [], 2: [], "crossed": 0},
    "SOUTH": {0: [], 1: [], 2: [], "crossed": 0},
}

# Gap between vehicles
stoppingGap = 15  # stopping gap
movingGap = 15  # moving gap

# init and group
pygame.init()
simulation = pygame.sprite.Group()


class TrafficSignal:
    def __init__(self, red, yellow, green):
        self.red = red
        self.yellow = yellow
        self.green = green
        self.signalText = ""


class Vehicle(pygame.sprite.Sprite):
    speed: float  # speed of the vehicle
    side: str  # side of the intersection
    direction_number: int  # will explain later
    lane_number: int  # which lane you are in
    x: int  # x-position
    y: int  # y-position
    croseed: bool  # has crossed the signal
    index: int  # position in the queue
    image: str  # path of the image
    stop: tuple  # stopping co-ordinates

    def __init__(self, side, direction_number, lane) -> None:
        # initiliaze sprite

        pygame.sprite.Sprite.__init__(self)
        self.side = side
        self.lane = lane
        self.speed = float(defaults_config["SPEED"])
        self.direction_number = direction_number

        # set co-ordinates on side of vehicle, what is 3rd lane, let it be for some time
        self.x = x[side][lane]
        self.y = y[side][lane]

        # has the vehicle crossed the stop line?
        self.crossed = False

        # add this in the line or queue
        vehicles[side][lane].append(self)

        # personal index for how many in front
        self.index = len(vehicles[side][lane]) - 1

        #
        path = "assets/vehicles/" + side + ".png"
        self.image = pygame.image.load(path)

        if (
            len(vehicles[side][lane]) > 1  # if any vehicles are there
            and vehicles[side][lane][self.index - 1].crossed
            == 0  # and has it already crossed
        ):  # if more than 1 vehicle in the lane of vehicle before it has crossed stop line
            if side == "EAST":
                self.stop = (
                    vehicles[side][lane][self.index - 1].stop
                    - vehicles[side][lane][self.index - 1].image.get_rect().width
                    - stoppingGap
                )  # setting stop coordinate as: stop coordinate of next vehicle - width of next vehicle - gap

            elif side == "WEST":
                self.stop = (
                    vehicles[side][lane][self.index - 1].stop
                    + vehicles[side][lane][self.index - 1].image.get_rect().width
                    + stoppingGap
                )

            elif side == "NORTH":
                self.stop = (
                    vehicles[side][lane][self.index - 1].stop
                    - vehicles[side][lane][self.index - 1].image.get_rect().height
                    - stoppingGap
                )

            elif side == "SOUTH":
                self.stop = (
                    vehicles[side][lane][self.index - 1].stop
                    + vehicles[side][lane][self.index - 1].image.get_rect().height
                    + stoppingGap
                )
        else:
            self.stop = defaultStop[side]  # set the stop co-ordinates

        # Set new starting and stopping coordinate
        if side == "EAST":
            temp = self.image.get_rect().width + stoppingGap
            x[side][lane] -= temp
        elif side == "WEST":
            temp = self.image.get_rect().width + stoppingGap
            x[side][lane] += temp
        elif side == "NORTH":
            temp = self.image.get_rect().height + stoppingGap
            y[side][lane] -= temp
        elif side == "SOUTH":
            temp = self.image.get_rect().height + stoppingGap
            y[side][lane] += temp
        simulation.add(self)

    # render image on the screen
    def render(self, screen):
        screen.blit(self.image, (self.x, self.y))

    # move the vehicle
    def move(self):
        if self.side == "EAST":
            if (
                self.crossed == 0
                and self.x + self.image.get_rect().width > stopLines[self.side]
            ):  # if the image has crossed stop line now
                self.crossed = 1

            if (
                self.x + self.image.get_rect().width <= self.stop
                or self.crossed == 1
                or (currentGreen == 0 and currentYellow == 0)
            ) and (
                self.index == 0
                or self.x + self.image.get_rect().width
                < (vehicles[self.side][self.lane][self.index - 1].x - movingGap)
            ):
                # (if the image has not reached its stop coordinate or has crossed stop line or has green signal) and (it is either the first vehicle in that lane or it is has enough gap to the next vehicle in that lane)
                self.x += self.speed  # move the vehicle

        elif self.side == "NORTH":
            if (
                self.crossed == 0
                and self.y + self.image.get_rect().height > stopLines[self.side]
            ):
                self.crossed = 1

            if (
                self.y + self.image.get_rect().height <= self.stop
                or self.crossed == 1
                or (currentGreen == 1 and currentYellow == 0)
            ) and (
                self.index == 0
                or self.y + self.image.get_rect().height
                < (vehicles[self.side][self.lane][self.index - 1].y - movingGap)
            ):
                self.y += self.speed

        elif self.side == "WEST":
            if self.crossed == 0 and self.x < stopLines[self.side]:
                self.crossed = 1
            if (
                self.x >= self.stop
                or self.crossed == 1
                or (currentGreen == 2 and currentYellow == 0)
            ) and (
                self.index == 0
                or self.x
                > (
                    vehicles[self.side][self.lane][self.index - 1].x
                    + vehicles[self.side][self.lane][self.index - 1]
                    .image.get_rect()
                    .width
                    + movingGap
                )
            ):
                self.x -= self.speed

        elif self.side == "SOUTH":
            if self.crossed == 0 and self.y < stopLines[self.side]:
                self.crossed = 1
            if (
                self.y >= self.stop
                or self.crossed == 1
                or (currentGreen == 3 and currentYellow == 0)
            ) and (
                self.index == 0
                or self.y
                > (
                    vehicles[self.side][self.lane][self.index - 1].y
                    + vehicles[self.side][self.lane][self.index - 1]
                    .image.get_rect()
                    .height
                    + movingGap
                )
            ):
                self.y -= self.speed


# Initialization of signals with default values
def initialize():
    s1 = TrafficSignal(0, defaultYellow, defaultGreen[0])
    signals.append(s1)

    s2 = TrafficSignal(s1.red + s1.yellow + s1.green, defaultYellow, defaultGreen[1])
    signals.append(s2)

    s3 = TrafficSignal(defaultRed, defaultYellow, defaultGreen[2])
    signals.append(s3)

    s4 = TrafficSignal(defaultRed, defaultYellow, defaultGreen[3])
    signals.append(s4)

    repeat()


# eat..sleep..
def repeat():
    global currentGreen, currentYellow, nextGreen
    while (
        signals[currentGreen].green > 0
    ):  # while the timer of current green signal is not zero
        updateValues()
        time.sleep(1)

    currentYellow = 1  # set yellow signal on

    # reset stop coordinates of lanes and vehicles
    for i in range(0, 3):
        for vehicle in vehicles[directionNumbers[currentGreen]][i]:
            vehicle.stop = defaultStop[directionNumbers[currentGreen]]

    while (
        signals[currentGreen].yellow > 0
    ):  # while the timer of current yellow signal is not zero
        updateValues()
        time.sleep(1)

    currentYellow = 0  # set yellow signal off

    # reset all signal times of current signal to default times
    signals[currentGreen].green = defaultGreen[currentGreen]
    signals[currentGreen].yellow = defaultYellow
    signals[currentGreen].red = defaultRed

    currentGreen = nextGreen  # set next signal as green signal
    nextGreen = (currentGreen + 1) % noOfSignals  # set next green signal
    signals[nextGreen].red = (
        signals[currentGreen].yellow + signals[currentGreen].green
    )  # set the red time of next to next signal as (yellow time + green time) of next signal
    repeat()


# Update values of the signal timers after every second
def updateValues():
    for i in range(0, noOfSignals):
        if i == currentGreen:
            if currentYellow == 0:
                signals[i].green -= 1
            else:
                signals[i].yellow -= 1
        else:
            signals[i].red -= 1


# Generating vehicles in the simulation, this will be from other class, that is sensor shit
def generateVehicles():
    while True:
        # only one lane so, not needed tbh
        lane_number = random.randint(0, 1)
        temp = random.randint(0, 99)

        direction_number = 0

        # distance
        dist = [25, 50, 75, 100]
        if temp < dist[0]:
            direction_number = 0

        elif temp < dist[1]:
            direction_number = 1

        elif temp < dist[2]:
            direction_number = 2

        elif temp < dist[3]:
            direction_number = 3
        Vehicle(
            lane=lane_number,
            direction_number=direction_number,
            side=directionNumbers[direction_number],
        )
        # zopava tyachya aaila
        time.sleep(1)


# ata bajar uthel
class Main:
    # ofcourse
    # threading: signal change does not depend on how many vechicles the sensor detects, both should work on their own
    thread1 = threading.Thread(
        name="initialization", target=initialize, args=()
    )  # initialization
    thread1.daemon = True
    thread1.start()

    # Colours
    black = (0, 0, 0)
    white = (255, 255, 255)

    screenSize = (screenWidth, screenHeight)

    # Setting background image i.e. image of intersection
    screen = pygame.display.set_mode(screenSize)
    pygame.display.set_caption("IntelliCross - Smart Traffic Control Signal")

    background = pygame.image.load("assets/intersection.jpg").convert()
    background = pygame.transform.smoothscale(background, screenSize)
    screen.blit(background, (0, 0))

    # Loading signal images and font
    redSignal = pygame.image.load("assets/signals/red.png")
    yellowSignal = pygame.image.load("assets/signals/yellow.png")
    greenSignal = pygame.image.load("assets/signals/green.png")

    # ithe jra interesting kai tri kru
    font = pygame.font.Font(None, 30)

    # this is generation
    thread2 = threading.Thread(
        name="generateVehicles", target=generateVehicles, args=()
    )  # Generating vehicles
    thread2.daemon = True
    thread2.start()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

        # display background in simulation
        screen.blit(background, (0, 0))

        # display signal and set timer according to current status: green, yello, or red
        for i in range(0, noOfSignals):
            if i == currentGreen:
                if currentYellow == 1:
                    signals[i].signalText = signals[i].yellow
                    screen.blit(yellowSignal, signalCoods[i])
                else:
                    signals[i].signalText = signals[i].green
                    screen.blit(greenSignal, signalCoods[i])
            else:
                if signals[i].red <= 10:
                    signals[i].signalText = signals[i].red
                else:
                    signals[i].signalText = "---"
                screen.blit(redSignal, signalCoods[i])
        signalTexts = ["", "", "", ""]

        # display signal timer
        for i in range(0, noOfSignals):
            signalTexts[i] = font.render(str(signals[i].signalText), True, white, black)
            screen.blit(signalTexts[i], signalTimerCoods[i])

        # display the vehicles
        for vehicle in simulation:
            screen.blit(vehicle.image, [vehicle.x, vehicle.y])
            vehicle.move()

        # keep it running
        pygame.display.update()


Main()


class Simulate:
    def __init__(self) -> None:
        pass

    def manageSignal(self) -> None:
        pass

    # individual Vehicle
    def manageVehicle(self) -> None:
        pass

    # all vehicles
    def manageVehicles(self) -> None:
        pass

    def startSimulation(self) -> None:
        pass

    def stopSimulation(self) -> None:
        pass

    def getUserInput(self) -> None:
        pass
